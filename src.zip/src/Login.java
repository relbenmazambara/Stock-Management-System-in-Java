import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.border.SoftBevelBorder;
import javax.swing.text.JTextComponent;

import Images.Dashboard;

import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	private JLabel lblmsg = new JLabel("");
	Connection conn =null;
	PreparedStatement st =null;
	ResultSet rs =null;
	

	//private Image lback =new ImageIcon(Login.class.getResource("Images/BACKL.jpg")).getImage().getScaledInstance(830,515,Image.SCALE_SMOOTH);
	private Image luser =new ImageIcon(Login.class.getResource("Images/USERNAME.png")).getImage().getScaledInstance(53,54,Image.SCALE_SMOOTH);
	private Image lpass =new ImageIcon(Login.class.getResource("Images/OIP.jpg")).getImage().getScaledInstance(41,43,Image.SCALE_SMOOTH);
	//private Image llogin =new ImageIcon(Login.class.getResource("Images/login.jpg")).getImage().getScaledInstance(54,42,Image.SCALE_SMOOTH);
	


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 852, 539);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(31, 193, 725, 322);
		contentPane.add(panel);
		setUndecorated(true);
		panel.setLayout(null);
		
		JLabel lblUsername = new JLabel("USERNAME");
		lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblUsername.setForeground(new Color(0, 100, 0));
		lblUsername.setBackground(new Color(255, 255, 255));
		lblUsername.setBounds(37, 75, 163, 29);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("PASSWORD");
		lblPassword.setForeground(new Color(0, 100, 0));
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 23));
		lblPassword.setBackground(Color.WHITE);
		lblPassword.setBounds(37, 200, 163, 29);
		panel.add(lblPassword);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(400, 50, 256, 54);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtUsername.getText().equals("username")) {
					txtUsername.setText("");
				}
			else {
						txtUsername.selectAll();
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
                 if(txtUsername.getText().equals(""));
			}
		});
		txtUsername.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtUsername.setText("Username");
		txtUsername.setBounds(10, 11, 194, 31);
		panel_1.add(txtUsername);
		txtUsername.setColumns(10);
		
		JLabel lbluser = new JLabel("");
		lbluser.setIcon(new ImageIcon(luser));
		lbluser.setBounds(208, 11, 42, 33);
		panel_1.add(lbluser);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBounds(400, 193, 256, 54);
		panel.add(panel_1_1);
		
		txtPassword = new JPasswordField();
		txtPassword.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (txtPassword.getText().equals("Password")) {
					txtPassword.setEchoChar('*');
					txtPassword.setText("");
				}
			else {
						txtPassword.selectAll();
				}
				
			}
			@Override
			public void focusLost(FocusEvent e) {
				 if(txtPassword.getText().equals(""));
				 //txtPassword.setText("Password");
				 txtPassword.setEchoChar((char)0);
			}
		

		});
		txtPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtPassword.setText("Password");
		txtPassword.setToolTipText("");
		txtPassword.setBounds(10, 11, 202, 32);
		panel_1_1.add(txtPassword);
		
		JLabel lblpass = new JLabel("");
		lblpass.setBounds(215, 7, 41, 43);
		lblpass.setIcon(new ImageIcon(lpass));
		panel_1_1.add(lblpass);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_2.setBackground(new Color(0, 100, 0));
		panel_2.setBounds(400, 258, 256, 53);
		panel.add(panel_2);
		panel_2.setLayout(null);
		//LOGIN BUTTON PROGRAM
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					String userName = txtUsername.getText();
					String password =txtPassword.getText();
					try {
						String query =("SELECT * FROM users WHERE username=? and password =?");
						conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/stockmanagementsystem","root","");
						st = conn.prepareStatement(query);
						st.setString(1 ,userName);
						st.setString(2,password);
						rs=st.executeQuery();
						if(rs.next()) {
							JOptionPane.showMessageDialog(null,"You Are Successfully Loged In ");
							
							Dashboard dsh = new Dashboard();
							dsh.setVisible(true);
						dispose();
							}
						else {
						JOptionPane.showMessageDialog(null,"Incorrect Details; ... Please INSERT CORRECT DETAILS ");
						}
					}
	                         catch (Exception ex) {
	                        	 JOptionPane.showMessageDialog(panel_1,"Database Error");
	                         }		
				}
		});
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnLogin.setBounds(10, 11, 236, 31);
		panel_2.add(btnLogin);
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnLogin.setBounds(10, 11, 236, 31);
		panel_2.add(btnLogin);
		
		JLabel lblmsg = new JLabel("");
		lblmsg.setForeground(Color.RED);
		lblmsg.setFont(new Font("Times New Roman", Font.BOLD, 40));
		lblmsg.setBounds(45, 124, 611, 45);
		panel.add(lblmsg);
		
		JLabel lblNewLabel = new JLabel("User Login");
		lblNewLabel.setForeground(new Color(240, 255, 240));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(51, 47, 222, 60);
		contentPane.add(lblNewLabel);
		
		JLabel lblEXIT = new JLabel("X");
		// CREATING AN EXIT BUTTON
				lblEXIT.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						if(JOptionPane.showConfirmDialog(null,"Are you sure you want to close the Application","Confirmation",JOptionPane.YES_NO_OPTION)==0) {
							Login.this.dispose();
						}
					}

					@Override
					public void mouseEntered(MouseEvent e) {
						lblEXIT.setForeground(Color.red);
					}
					
					@Override
					public void mouseExited(MouseEvent e) {
						lblEXIT.setForeground(Color.white);
					}
				});
		lblEXIT.setForeground(new Color(255, 0, 0));
		lblEXIT.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblEXIT.setBounds(827, 0, 25, 32);
		contentPane.add(lblEXIT);
	}
}
