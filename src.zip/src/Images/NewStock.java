package Images;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.border.EtchedBorder;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class NewStock extends JPanel {
	private JTextField txtProductCode;
	private JTextField txtProductName;
	private JTextField txtProductQuantity;
	private JTextField txtProductPrice;
	Connection conn =null;
	PreparedStatement st =null;
	ResultSet rs =null;

	/**
	 * Create the panel.
	 */
	public NewStock() {
		setBackground(new Color(0, 206, 209));
		setBounds(164,55,1155,610);
		setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		panel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBounds(116, 69, 912, 431);
		add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("PRODUCT CODE:");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel.setBounds(39, 66, 230, 30);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PRODUCT NAME:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1.setBounds(39, 172, 230, 30);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("PRODUCT QUANTITY:");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_1.setBounds(39, 284, 280, 30);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("PRICE/UNITY/QUANTITY:");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_1_2.setBounds(39, 395, 314, 30);
		panel.add(lblNewLabel_1_2);
		//product that fetch data from database into textboxes using id
		txtProductCode = new JTextField();
		txtProductCode.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
			try {
				conn = DriverManager.getConnection("jdbc:mysql://localhost/stockmanagementsystem","root","");
				String sql = "SELECT * FROM  stocktable WHERE productcode =?";
				PreparedStatement pst =conn.prepareStatement(sql);
				pst.setString(1,txtProductCode.getText());
				ResultSet rs=pst.executeQuery();
				while(rs.next()) {
					String setid =rs.getString("productcode");
					txtProductCode.setText(setid);
					txtProductName.setText(rs.getString("productname"));
					txtProductQuantity.setText(rs.getString("productyquantity"));
					txtProductPrice.setText(rs.getString("price"));
				}
				pst.close();
				}catch( SQLException |HeadlessException ex){
					JOptionPane.showMessageDialog(null, "DATABASE ERROR !!");
				}
			}
		});
		txtProductCode.setFont(new Font("Tahoma", Font.BOLD, 19));
		txtProductCode.setBounds(549, 55, 251, 40);
		panel.add(txtProductCode);
		txtProductCode.setColumns(10);
		
		txtProductName = new JTextField();
		txtProductName.setFont(new Font("Tahoma", Font.BOLD, 19));
		txtProductName.setColumns(10);
		txtProductName.setBounds(549, 149, 251, 40);
		panel.add(txtProductName);
		
		txtProductQuantity = new JTextField();
		txtProductQuantity.setFont(new Font("Tahoma", Font.BOLD, 19));
		txtProductQuantity.setColumns(10);
		txtProductQuantity.setBounds(549, 261, 251, 40);
		panel.add(txtProductQuantity);
		
		txtProductPrice = new JTextField();
		txtProductPrice.setFont(new Font("Tahoma", Font.BOLD, 19));
		txtProductPrice.setColumns(10);
		txtProductPrice.setBounds(549, 373, 251, 40);
		panel.add(txtProductPrice);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_1.setBounds(46, 515, 1086, 84);
		add(panel_1);
		panel_1.setLayout(null);
		//program that take data from textbox to database
		JButton addBtn = new JButton("ADD PRODUCT ");
		addBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					String pcode =txtProductCode.getText();
					String pname = txtProductName.getText();
					String pquantity =txtProductQuantity.getText();
					String pprice =txtProductPrice.getText();
					
					try {
						
						String sql ="INSERT INTO stocktable(productcode, productname, productyquantity, price) VALUES (?,?,?,?)";
						
						conn = DriverManager.getConnection("jdbc:mysql://localhost/stockmanagementsystem","root","");
						st=conn.prepareStatement(sql);
						st.setString(1, pcode);
						st.setString(2, pname);
						st.setString(3, pquantity);
						st.setString(4, pprice);	
						st.executeUpdate();
						JOptionPane.showMessageDialog(null,"Product Added Successfully in Stock");
						}
					catch( SQLException | HeadlessException ex){
						JOptionPane.showMessageDialog(null, "DATABASE ERROR !!");
					}
			}
		});
		addBtn.setForeground(Color.WHITE);
		addBtn.setBackground(new Color(0, 128, 0));
		addBtn.setFont(new Font("Times New Roman", Font.BOLD, 18));
		addBtn.setBounds(28, 36, 179, 37);
		panel_1.add(addBtn);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
            txtProductCode.setText("");
            txtProductName.setText("");
            txtProductQuantity.setText("");
            txtProductPrice.setText("");
				
			}
		});
		btnClear.setForeground(Color.WHITE);
		btnClear.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnClear.setBackground(new Color(0, 128, 0));
		btnClear.setBounds(302, 36, 179, 37);
		panel_1.add(btnClear);
		//Program that update product details
		JButton btnUpdateProductStock = new JButton("UPDATE PRODUCT STOCK ");
		btnUpdateProductStock.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		             try {
							
							String sql ="UPDATE `stocktable` SET productname=?, productyquantity=?, price=?  WHERE productcode= ?";			
							conn = DriverManager.getConnection("jdbc:mysql://localhost/stockmanagementsystem","root","");
							st=conn.prepareStatement(sql);
							st.setString(1, txtProductName.getText());
							st.setString(2, txtProductQuantity.getText());
							st.setString(3, txtProductPrice.getText());
							st.setInt(4, Integer.parseInt(txtProductCode.getText()));
							st.executeUpdate();
							JOptionPane.showMessageDialog(null,"Product Details Updated Successfully");
							}
						catch( SQLException | HeadlessException ex){
							JOptionPane.showMessageDialog(null, "DATABASE ERROR !!");
						}
					}
		});
		btnUpdateProductStock.setForeground(Color.WHITE);
		btnUpdateProductStock.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnUpdateProductStock.setBackground(new Color(0, 128, 0));
		btnUpdateProductStock.setBounds(541, 36, 277, 37);
		panel_1.add(btnUpdateProductStock);
		
		JButton btnDeleteProduct = new JButton("DELETE PRODUCT ");
		btnDeleteProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql ="DELETE FROM `stocktable` WHERE productcode= ?";
					
					conn = DriverManager.getConnection("jdbc:mysql://localhost/stockmanagementsystem","root","");
					st=conn.prepareStatement(sql);
					st.setString(1, txtProductCode.getText());
					st.executeUpdate();
					JOptionPane.showMessageDialog(null,"Product Deleted From Stock Successfully !");
				}
				catch( SQLException | HeadlessException ex){
					JOptionPane.showMessageDialog(null, "DATABASE ERROR !!");
				}
			}
		});
		btnDeleteProduct.setForeground(Color.WHITE);
		btnDeleteProduct.setFont(new Font("Times New Roman", Font.BOLD, 18));
		btnDeleteProduct.setBackground(new Color(0, 128, 0));
		btnDeleteProduct.setBounds(867, 36, 209, 37);
		panel_1.add(btnDeleteProduct);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		panel_2.setBounds(406, 11, 302, 47);
		add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("NEW STOCK FORM");
		lblNewLabel_2.setForeground(new Color(128, 0, 0));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblNewLabel_2.setBounds(10, 11, 277, 25);
		panel_2.add(lblNewLabel_2);

	}
}
