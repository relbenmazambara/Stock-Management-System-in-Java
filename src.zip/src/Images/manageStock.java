package Images;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.HeadlessException;

import javax.swing.JTable;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class manageStock extends JPanel {
	private JTable table;
	Connection conn =null;
	PreparedStatement st =null;
	ResultSet rs =null;


	/**
	 * Create the panel.
	 */
	public manageStock() {
		setBackground(new Color(0, 0, 128));
		setBounds(0,0,1155,610);
		setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 40, 185, 2);
		add(separator);
		
		JLabel lblNewLabel = new JLabel("Manage Stock");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(10, 11, 199, 29);
		add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 139, 139));
		panel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBounds(10, 50, 1135, 549);
		add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 1115, 527);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product Code", "Product Name", "Product Quantity", "Price", "Date Odered"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(95);
		table.getColumnModel().getColumn(0).setMinWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(211);
		table.getColumnModel().getColumn(2).setPreferredWidth(103);
		table.getColumnModel().getColumn(3).setPreferredWidth(112);
		table.getColumnModel().getColumn(4).setPreferredWidth(95);
		
		JButton manageStockBtn = new JButton("Manage");
		manageStockBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					String sql ="SELECT * FROM stocktable";
					conn = DriverManager.getConnection("jdbc:mysql://localhost/stockmanagementsystem","root","");
					PreparedStatement pst = conn.prepareStatement(sql);
					ResultSet rs = pst.executeQuery();
					DefaultTableModel model =(DefaultTableModel) table.getModel();
					while(rs.next()) {
						model.addRow(new String[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
					}
					
				}
				catch( SQLException | HeadlessException ex){
					JOptionPane.showMessageDialog(null, ex);
				}
				
			}
		});
		manageStockBtn.setBackground(new Color(128, 0, 128));
		manageStockBtn.setForeground(new Color(255, 255, 255));
		manageStockBtn.setFont(new Font("Tahoma", Font.BOLD, 17));
		manageStockBtn.setBounds(1002, 11, 143, 31);
		add(manageStockBtn);

	}
}
