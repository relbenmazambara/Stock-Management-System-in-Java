package Images;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
	public static void main(String args[]) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/stockmanagementsystem","root","");
			if(!conn.isClosed())
				System.out.println("Successfully connected to MySQL sever...");
			
		} catch (Exception e) {
			System.err.println("Exception:"+ e.getMessage());
		}finally {
			try {
				if(conn !=null)
					conn.close();
				
			}catch (Exception e) {}
		}
	}

}
