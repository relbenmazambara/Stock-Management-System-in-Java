package Images;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import Images.NewStock;
import Images.manageStock;


import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.MouseEvent;

import javax.swing.border.SoftBevelBorder;

import javax.swing.border.BevelBorder;
import java.awt.event.MouseAdapter;

public class Dashboard<Login> extends JFrame {

	private JPanel contentPane;
	
	private NewStock newstock;
	private manageStock managestock;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard frame = new Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Dashboard() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1345, 715);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		newstock = new NewStock();
		managestock = new manageStock();
		panel.setBackground(new Color(0, 128, 0));
		panel.setBounds(10, 55, 144, 660);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel newstockpanel = new JPanel();
		newstockpanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(newstock);
				
			}

		});
		newstockpanel.setBounds(10, 60, 124, 38);
		panel.add(newstockpanel);
		newstockpanel.setLayout(null);
		
		
		JLabel lblNewLabel_1 = new JLabel("NEW STOCK");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 11, 104, 16);
		newstockpanel.add(lblNewLabel_1);
		
		JPanel manageStockPanel = new JPanel();
		manageStockPanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				menuClicked(managestock);
				
			}

		});
		manageStockPanel.setBounds(10, 177, 124, 38);
		panel.add(manageStockPanel);
		manageStockPanel.setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("MANAGE STOCK");
		manageStockPanel.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setBounds(10, 11, 114, 16);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 274, 124, 38);
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("SELL STOCK");
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1_1_1.setBounds(10, 11, 114, 16);
		panel_4.add(lblNewLabel_1_1_1);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(10, 370, 124, 38);
		panel.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblNewLabel_1_1_1_1_2 = new JLabel("CREATE REPORTS");
		lblNewLabel_1_1_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1_1_1_1_2.setBounds(0, 11, 124, 16);
		panel_5.add(lblNewLabel_1_1_1_1_2);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBounds(10, 463, 124, 38);
		panel.add(panel_6);
		panel_6.setLayout(null);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("MANAGE USERS");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel_1_1_1_1_1.setBounds(10, 11, 114, 16);
		panel_6.add(lblNewLabel_1_1_1_1_1);
		
		JPanel logoutPanel = new JPanel();
		logoutPanel.addMouseListener(new MouseAdapter() {
			@Override
			public  void mouseClicked(MouseEvent e) {
						if(JOptionPane.showConfirmDialog(null, "Are Sure You Want To Logout")==0) {}
					//Login kg = new Login();
					//kg.setVisible(true);
					Dashboard.this.setVisible(false);
					}
		});
		logoutPanel.setBounds(10, 571, 124, 38);
		panel.add(logoutPanel);
		logoutPanel.setLayout(null);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("LOGOUT");
		lblNewLabel_1_1_1_1.setBounds(33, 11, 81, 16);
		logoutPanel.add(lblNewLabel_1_1_1_1);
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 14));
		
		JPanel maincontentpanel = new JPanel();
		maincontentpanel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		newstock= new NewStock();
		newstock.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		newstock.setBounds(0,0,1155,610);
		menuClicked(newstock);
		maincontentpanel.setBackground(new Color(192, 192, 192));
		maincontentpanel.setBounds(164, 55, 1155, 610);
		contentPane.add(maincontentpanel);
		maincontentpanel.setLayout(null);
		maincontentpanel.add(newstock);
		maincontentpanel.add(managestock);
		
		JLabel lblNewLabel = new JLabel("Dashboard");
		lblNewLabel.setForeground(new Color(0, 0, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 32));
		lblNewLabel.setBounds(10, 11, 166, 33);
		contentPane.add(lblNewLabel);
		//setUndecorated(true);
		
	}
	public void menuClicked(JPanel panel) {
		newstock.setVisible(false);
		managestock.setVisible(false);
		panel.setVisible(true);
	}
	
	

	private class PanelButtonMouseAdapter extends MouseAdapter{
		JPanel panel;
		public PanelButtonMouseAdapter(JPanel panel) {
			this.panel=panel;
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			panel.setBackground(new Color(112,128,144));
		}
		@Override
		public void mouseExited(MouseEvent e) {
			panel.setBackground(new Color(47,79,79));
		}
		@Override
		public void mousePressed(MouseEvent e) {
			panel.setBackground(new Color(112,128,144));
		}
		@Override
		public void mouseReleased(MouseEvent e) {
			panel.setBackground(new Color(112,128,144));

		}
		
	}
	
		
		}
	
	
	

